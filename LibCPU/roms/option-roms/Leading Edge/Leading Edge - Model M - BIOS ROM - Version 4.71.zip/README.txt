Ray,

I have an OLD Leading Edge Model M computer with Dual 360K 48TPI
Floppy Drives.  I believe it to be an 8088 and it had a ROM that did not
allow EGA Cards to be used.  I purchased a New BIOS EPROM that
allowed the EGA cards.  ROM was Marked M417 as well as I remember.

I can send Photo once I get back home in April.  I've attached a copy of the ROM as I saved a copy years ago, and forgot about it until now.  I don't have
a copy of the original BIOS ROM, but may get a VCF Member to dump it.

It is in a two byte ASCII format (Needham Format) and two ASCII Bytes make up the one HEX 0x00 byte.  I'm also sending an ASCII DUMP, done with srec_cat.

Someone might be looking to upgrade their OLD Model "M".

Thanks.

Larry Kraemer


