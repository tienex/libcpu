SMC4003-PC
STANDARD MICROSYSTEMS CORPORATION

Main components:
U30 - M2764 (ROM)
U11 - HDC9224 (universal disk controller)
U10 - SMC HDC9226 (data separator)