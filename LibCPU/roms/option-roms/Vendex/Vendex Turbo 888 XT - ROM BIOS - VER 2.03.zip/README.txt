These are two BIOS ROM images from the Vendex Turbo 888 XT.

The pictures included show the labels from the ROM Images.

They are both a Phoenix ROM BIOS Version 2.03.
They only differ by a single byte.
The A ROM is on a 27128 ROM that auto-identifies in my Batronix as 21V
The B ROM identifies as an AMD 27128 but 12.5V.

I have three different CPU Boards for this system and two had the C revision.
