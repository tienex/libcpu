

From an Eagle 1600 Model 1630