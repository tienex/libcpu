

---------------------------------
SUPPLIED SUNIX/SUNIX BIOS
---------------------------------

To call the LLF routine with DEBUG, the address C800:6 must be called; not C800:5

